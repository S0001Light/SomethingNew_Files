#!/usr/bin/env python3

import os
import shutil
import subprocess
import sys


def run(command):
    print()
    print("Running:")
    print(" ".join(command))
    print()

    try:
        subprocess.check_call(command)
        return True

    except subprocess.CalledProcessError as error:
        print()
        print("Command failed:")
        print(error)

        return False


def find_chromium():
    for command in (
        "chromium",
        "chromium-browser",
    ):
        path = shutil.which(command)

        if path:
            return path

    return None


def main():
    print()
    print("========================================")
    print(" WritersJumbler YouTube Viewer")
    print(" Raspberry Pi OS Installer")
    print("========================================")
    print()

    print("No PyQt packages are required.")
    print()

    current_chromium = find_chromium()

    if current_chromium:
        print("Chromium is already installed:")
        print(current_chromium)
        print()
        print("Installation is complete.")
        print()
        print("Run:")
        print()
        print("python3 youtube_pi.py")

        return 0

    if not shutil.which("apt-get"):
        print("APT was not found.")
        print()
        print(
            "This installer requires Raspberry Pi OS "
            "or another Debian-based system."
        )

        return 1

    if os.geteuid() == 0:
        prefix = []

    elif shutil.which("sudo"):
        prefix = ["sudo"]

    else:
        print("Administrator access is required.")
        print()
        print("Run:")
        print()
        print(
            "sudo python3 install_packages.py"
        )

        return 1

    if not run(
        prefix + [
            "apt-get",
            "update",
        ]
    ):
        return 1

    # Current Raspberry Pi OS generally uses the
    # package name "chromium".
    if run(
        prefix + [
            "apt-get",
            "install",
            "-y",
            "chromium",
        ]
    ):
        chromium = find_chromium()

        if chromium:
            print()
            print("Chromium installed:")
            print(chromium)
            print()
            print("Run:")
            print()
            print("python3 youtube_pi.py")

            return 0

    print()
    print(
        "The package named chromium was unavailable."
    )

    print(
        "Trying the older Raspberry Pi OS package name."
    )

    if run(
        prefix + [
            "apt-get",
            "install",
            "-y",
            "chromium-browser",
        ]
    ):
        chromium = find_chromium()

        if chromium:
            print()
            print("Chromium installed:")
            print(chromium)
            print()
            print("Run:")
            print()
            print("python3 youtube_pi.py")

            return 0

    print()
    print("Chromium could not be installed.")

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
