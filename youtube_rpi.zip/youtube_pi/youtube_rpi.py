#!/usr/bin/env python3

import os
import shutil
import signal
import subprocess
import sys
import time


HOME_URL = "https://www.youtube.com/"

PROFILE_DIRECTORY = os.path.expanduser(
    "~/.config/writersjumbler-youtube"
)


def find_chromium():
    """
    Find the Chromium executable installed by Raspberry Pi OS.
    """

    possible_commands = (
        "chromium",
        "chromium-browser",
    )

    for command in possible_commands:
        full_path = shutil.which(command)

        if full_path:
            return full_path

    possible_paths = (
        "/usr/bin/chromium",
        "/usr/bin/chromium-browser",
    )

    for path in possible_paths:
        if os.path.isfile(path):
            if os.access(path, os.X_OK):
                return path

    return None


def graphical_desktop_available():
    """
    Chromium needs an active graphical desktop.
    """

    return bool(
        os.environ.get("DISPLAY")
        or os.environ.get("WAYLAND_DISPLAY")
    )


def build_command(chromium_path):
    """
    Start YouTube as a normal maximized window.

    It does NOT start in kiosk/fullscreen mode.
    """

    return [
        chromium_path,

        # Start as a normal maximized window
        "--start-maximized",

        # Dedicated YouTube application window
        "--app=" + HOME_URL,

        # Separate WritersJumbler profile
        "--user-data-dir=" + PROFILE_DIRECTORY,

        "--no-first-run",
        "--no-default-browser-check",
        "--noerrdialogs",
        "--disable-session-crashed-bubble",
        "--hide-crash-restore-bubble",

        "--disable-translate",
        "--disable-features=TranslateUI",
        "--disable-component-update",
        "--disable-background-mode",

        # Touchscreen support
        "--touch-events=enabled",
        "--overscroll-history-navigation=0",

        # Media
        "--autoplay-policy=no-user-gesture-required",
    ]


def print_help():
    print()
    print("WritersJumbler YouTube Viewer")
    print("--------------------------------")
    print()
    print("Keyboard controls:")
    print()
    print("  F11              Toggle fullscreen")
    print("  Alt + Left       Go back")
    print("  Alt + Right      Go forward")
    print("  Ctrl + R         Reload")
    print("  Ctrl + L         Focus address/search")
    print("  Ctrl + W         Close viewer")
    print()
    print("Touchscreen:")
    print()
    print("  Touch YouTube's search field to type.")
    print(
        "  Raspberry Pi OS should display its "
        "  configured on-screen keyboard."
    )
    print()
    print(
        "  Swipe and touch controls are handled "
        "  natively by Chromium."
    )
    print()


def main():
    print()
    print("========================================")
    print(" WritersJumbler YouTube Viewer")
    print(" Chromium Raspberry Pi Edition")
    print("========================================")
    print()

    if os.geteuid() == 0:
        print("Do not run this program using sudo.")
        print()
        print("Run it as your normal desktop user:")
        print()
        print("python3 youtube_pi.py")
        print()

        return 1

    if not graphical_desktop_available():
        print("No graphical desktop was detected.")
        print()
        print(
            "Open Terminal from the Raspberry Pi "
            "desktop and run the program there."
        )
        print()

        return 1

    chromium_path = find_chromium()

    if chromium_path is None:
        print("Chromium was not found.")
        print()
        print("Install it with:")
        print()
        print("sudo apt update")
        print("sudo apt install chromium")
        print()

        return 1

    os.makedirs(
        PROFILE_DIRECTORY,
        exist_ok=True,
    )

    print("Chromium:")
    print(chromium_path)
    print()

    print("Profile:")
    print(PROFILE_DIRECTORY)
    print()

    print_help()

    command = build_command(
        chromium_path
    )

    process = None

    try:
        process = subprocess.Popen(
            command,
            start_new_session=True,
        )

        print("YouTube viewer started.")
        print()
        print(
            "Close Chromium normally or press "
            "Ctrl+C in this terminal."
        )
        print()

        return_code = process.wait()

        return return_code

    except KeyboardInterrupt:
        print()
        print("Closing YouTube viewer...")

        if process is not None:
            try:
                os.killpg(
                    os.getpgid(process.pid),
                    signal.SIGTERM,
                )

                time.sleep(1)

            except ProcessLookupError:
                pass

        return 0

    except OSError as error:
        print()
        print("Chromium could not be started:")
        print(error)

        return 1


if __name__ == "__main__":
    raise SystemExit(main())
