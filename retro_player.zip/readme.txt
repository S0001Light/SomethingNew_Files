install python

py -m pip install -r requirements.txt

also, install VLC 64 bit

download a .wsz old winamp skin for player...