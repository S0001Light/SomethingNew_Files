import io
import json
import os
import random
import tempfile
import threading
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

try:
    from PIL import Image, ImageTk
except ImportError:
    Image = ImageTk = None

try:
    import vlc
except ImportError:
    vlc = None

APP_NAME = "WritersJumbler Retro Media Player"
APP_DIR = Path.home() / ".writersjumbler_retro_player"
STATIONS_FILE = APP_DIR / "home_radio.json"
RADIO_API = "https://de1.api.radio-browser.info/json/stations/search"
AUDIO_TYPES = [("Audio", "*.mp3 *.wav *.ogg *.flac *.m4a *.aac *.webm"), ("All files", "*.*")]
SKIN_TYPES = [("Winamp skins", "*.wsz *.zip"), ("Images", "*.bmp *.png *.jpg *.jpeg *.gif *.webp"), ("All files", "*.*")]


def format_time(seconds):
    try:
        seconds = max(0, int(seconds))
    except (TypeError, ValueError):
        seconds = 0
    return f"{seconds // 60}:{seconds % 60:02d}"


class RetroPlayer(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("980x690")
        self.minsize(820, 580)
        self.configure(bg="#11140f")

        APP_DIR.mkdir(parents=True, exist_ok=True)
        self.instance = vlc.Instance("--quiet") if vlc else None
        self.player = self.instance.media_player_new() if self.instance else None
        self.tracks = []
        self.current_index = -1
        self.current_radio_id = None
        self.playing = False
        self.dragging_seek = False
        self.repeat = tk.BooleanVar(value=False)
        self.shuffle = tk.BooleanVar(value=False)
        self.volume = tk.IntVar(value=80)
        self.balance = tk.IntVar(value=0)
        self.status = tk.StringVar(value="READY")
        self.track_text = tk.StringVar(value="NO TRACK LOADED")
        self.time_text = tk.StringVar(value="0:00 / 0:00")
        self.skin_name = tk.StringVar(value="BUILT-IN RETRO")
        self.skin_images = {}
        self.skin_photo = None
        self.playlist_skin_photo = None
        self.stations = self.load_stations()
        self.directory_results = []

        self._build_styles()
        self._build_ui()
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.after(250, self.update_playback_ui)

        if not self.player:
            self.status.set("INSTALL python-vlc AND VLC DESKTOP")

    def _build_styles(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("Retro.TFrame", background="#181d16")
        style.configure("Retro.TLabelframe", background="#181d16", foreground="#b8ff8b")
        style.configure("Retro.TLabelframe.Label", background="#181d16", foreground="#b8ff8b", font=("Consolas", 11, "bold"))
        style.configure("Retro.TLabel", background="#181d16", foreground="#b8ff8b", font=("Consolas", 9))
        style.configure("Retro.TButton", background="#2b3327", foreground="#dcffc8", font=("Consolas", 9, "bold"), padding=6)
        style.map("Retro.TButton", background=[("active", "#3d4937")])
        style.configure("Retro.TCheckbutton", background="#181d16", foreground="#b8ff8b")
        style.configure("Green.Horizontal.TProgressbar", troughcolor="#071006", background="#65ff43")

    def _build_ui(self):
        root = ttk.Frame(self, style="Retro.TFrame", padding=12)
        root.pack(fill="both", expand=True)
        root.columnconfigure(1, weight=1)
        root.rowconfigure(0, weight=1)

        left = ttk.Frame(root, style="Retro.TFrame")
        left.grid(row=0, column=0, sticky="nsw", padx=(0, 12))
        right = ttk.Frame(root, style="Retro.TFrame")
        right.grid(row=0, column=1, sticky="nsew")
        right.columnconfigure(0, weight=1)
        right.rowconfigure(2, weight=1)

        self._build_player(left)
        self._build_playlist(left)
        self._build_load_panel(right)
        self._build_skin_panel(right)
        self._build_radio_notebook(right)

    def _build_player(self, parent):
        self.player_canvas = tk.Canvas(parent, width=550, height=232, bg="#101510", highlightthickness=2, highlightbackground="#77806f")
        self.player_canvas.pack()
        self.player_canvas.create_rectangle(0, 0, 550, 232, fill="#141a15", outline="")
        self.player_canvas.create_text(12, 12, anchor="nw", fill="#d8ffc1", font=("Consolas", 10, "bold"), text=APP_NAME.upper())
        self.canvas_track = self.player_canvas.create_text(220, 55, anchor="nw", width=310, fill="#a9ff79", font=("Consolas", 10), text=self.track_text.get())
        self.canvas_time = self.player_canvas.create_text(28, 52, anchor="nw", fill="#a9ff79", font=("Consolas", 26, "bold"), text="0:00")
        self.canvas_status = self.player_canvas.create_text(220, 85, anchor="nw", width=310, fill="#84a57a", font=("Consolas", 8), text="READY")

        self.seek = ttk.Scale(parent, from_=0, to=1000, orient="horizontal")
        self.seek.place(in_=self.player_canvas, x=25, y=130, width=500)
        self.seek.bind("<ButtonPress-1>", lambda _e: setattr(self, "dragging_seek", True))
        self.seek.bind("<ButtonRelease-1>", self.seek_release)

        controls = ttk.Frame(parent, style="Retro.TFrame")
        controls.pack(fill="x", pady=(6, 3))
        for text, command in [("|<<", self.previous), (">", self.play), ("||", self.pause), ("[]", self.stop), (">>|", self.next_track), ("OPEN", self.add_audio)]:
            ttk.Button(controls, text=text, command=command, style="Retro.TButton").pack(side="left", padx=2)
        ttk.Checkbutton(controls, text="SHUF", variable=self.shuffle, style="Retro.TCheckbutton").pack(side="left", padx=4)
        ttk.Checkbutton(controls, text="REP", variable=self.repeat, style="Retro.TCheckbutton").pack(side="left")

        sliders = ttk.Frame(parent, style="Retro.TFrame")
        sliders.pack(fill="x", pady=(3, 8))
        ttk.Label(sliders, text="VOL", style="Retro.TLabel").pack(side="left")
        ttk.Scale(sliders, from_=0, to=100, variable=self.volume, command=self.change_volume).pack(side="left", fill="x", expand=True, padx=5)
        ttk.Label(sliders, text="BAL", style="Retro.TLabel").pack(side="left")
        ttk.Scale(sliders, from_=-100, to=100, variable=self.balance, command=self.change_balance).pack(side="left", fill="x", expand=True, padx=5)

    def _build_playlist(self, parent):
        box = ttk.LabelFrame(parent, text="PLAYLIST", style="Retro.TLabelframe", padding=6)
        box.pack(fill="both", expand=True)
        self.playlist = tk.Listbox(box, width=48, height=16, bg="#050805", fg="#61ff42", selectbackground="#17551d", selectforeground="white", font=("Consolas", 9), activestyle="none")
        self.playlist.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(box, command=self.playlist.yview)
        scroll.pack(side="right", fill="y")
        self.playlist.configure(yscrollcommand=scroll.set)
        self.playlist.bind("<Double-Button-1>", self.play_selected)
        buttons = ttk.Frame(parent, style="Retro.TFrame")
        buttons.pack(fill="x")
        ttk.Button(buttons, text="ADD", command=self.add_audio, style="Retro.TButton").pack(side="left")
        ttk.Button(buttons, text="REMOVE", command=self.remove_selected, style="Retro.TButton").pack(side="left", padx=4)
        ttk.Button(buttons, text="CLEAR", command=self.clear_playlist, style="Retro.TButton").pack(side="left")

    def _build_load_panel(self, parent):
        panel = ttk.LabelFrame(parent, text="MUSIC", style="Retro.TLabelframe", padding=8)
        panel.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        panel.columnconfigure(0, weight=1)
        ttk.Button(panel, text="Add local audio", command=self.add_audio, style="Retro.TButton").grid(row=0, column=0, sticky="w")
        self.audio_url = ttk.Entry(panel)
        self.audio_url.grid(row=1, column=0, sticky="ew", pady=(7, 0))
        ttk.Button(panel, text="Add URL", command=self.add_audio_url, style="Retro.TButton").grid(row=1, column=1, padx=(6, 0), pady=(7, 0))

    def _build_skin_panel(self, parent):
        panel = ttk.LabelFrame(parent, text="CLASSIC WINAMP SKIN", style="Retro.TLabelframe", padding=8)
        panel.grid(row=1, column=0, sticky="ew", pady=(0, 8))
        ttk.Button(panel, text="Load .WSZ / .ZIP / image", command=self.choose_skin, style="Retro.TButton").pack(side="left")
        ttk.Button(panel, text="Reset skin", command=self.reset_skin, style="Retro.TButton").pack(side="left", padx=6)
        ttk.Label(panel, textvariable=self.skin_name, style="Retro.TLabel").pack(side="left", padx=6)

    def _build_radio_notebook(self, parent):
        notebook = ttk.Notebook(parent)
        notebook.grid(row=2, column=0, sticky="nsew")
        home = ttk.Frame(notebook, style="Retro.TFrame", padding=8)
        directory = ttk.Frame(notebook, style="Retro.TFrame", padding=8)
        notebook.add(home, text="Home Radio")
        notebook.add(directory, text="Station Directory")
        self._build_home_radio(home)
        self._build_directory(directory)

    def _build_home_radio(self, parent):
        parent.columnconfigure(0, weight=1)
        self.station_name = ttk.Entry(parent)
        self.station_name.grid(row=0, column=0, sticky="ew", padx=(0, 5))
        self.station_name.insert(0, "Station name")
        self.station_url = ttk.Entry(parent)
        self.station_url.grid(row=0, column=1, sticky="ew", padx=(0, 5))
        self.station_url.insert(0, "Direct stream URL")
        ttk.Button(parent, text="Save station", command=self.add_station, style="Retro.TButton").grid(row=0, column=2)
        self.station_list = tk.Listbox(parent, bg="#050805", fg="#61ff42", selectbackground="#17551d", font=("Consolas", 9), height=14)
        self.station_list.grid(row=1, column=0, columnspan=3, sticky="nsew", pady=8)
        parent.rowconfigure(1, weight=1)
        self.station_list.bind("<Double-Button-1>", lambda _e: self.play_home_station())
        bar = ttk.Frame(parent, style="Retro.TFrame")
        bar.grid(row=2, column=0, columnspan=3, sticky="w")
        ttk.Button(bar, text="Play", command=self.play_home_station, style="Retro.TButton").pack(side="left")
        ttk.Button(bar, text="Delete", command=self.delete_station, style="Retro.TButton").pack(side="left", padx=5)
        self.refresh_station_list()

    def _build_directory(self, parent):
        parent.columnconfigure(0, weight=1)
        parent.rowconfigure(2, weight=1)
        top = ttk.Frame(parent, style="Retro.TFrame")
        top.grid(row=0, column=0, sticky="ew")
        self.search_name = ttk.Entry(top, width=25)
        self.search_name.pack(side="left", fill="x", expand=True)
        self.genre = ttk.Combobox(top, width=14, state="readonly", values=["All genres", "rock", "pop", "jazz", "classical", "country", "blues", "electronic", "dance", "hip hop", "news", "talk", "sports", "oldies", "ambient"])
        self.genre.current(0); self.genre.pack(side="left", padx=5)
        countries = ["All countries", "US", "CA", "GB", "AU", "DE", "FR", "ES", "IT", "NL", "JP", "BR", "MX", "IN"]
        self.country = ttk.Combobox(top, width=14, state="readonly", values=countries)
        self.country.current(0); self.country.pack(side="left")
        ttk.Button(parent, text="Search stations", command=self.search_stations, style="Retro.TButton").grid(row=1, column=0, sticky="w", pady=6)
        self.results = ttk.Treeview(parent, columns=("country", "genre", "codec"), show="tree headings")
        self.results.heading("#0", text="Station")
        self.results.heading("country", text="Country")
        self.results.heading("genre", text="Genre")
        self.results.heading("codec", text="Audio")
        self.results.column("#0", width=230)
        self.results.column("country", width=100)
        self.results.column("genre", width=180)
        self.results.column("codec", width=90)
        self.results.grid(row=2, column=0, sticky="nsew")
        self.results.bind("<Double-Button-1>", lambda _e: self.play_directory_station())
        bottom = ttk.Frame(parent, style="Retro.TFrame")
        bottom.grid(row=3, column=0, sticky="w", pady=(6, 0))
        ttk.Button(bottom, text="Play", command=self.play_directory_station, style="Retro.TButton").pack(side="left")
        ttk.Button(bottom, text="Save to Home Radio", command=self.save_directory_station, style="Retro.TButton").pack(side="left", padx=5)

    def require_player(self):
        if self.player:
            return True
        messagebox.showerror(APP_NAME, "Install both VLC desktop and the Python package python-vlc.")
        return False

    def add_audio(self):
        for filename in filedialog.askopenfilenames(title="Add audio", filetypes=AUDIO_TYPES):
            self.add_track(Path(filename).stem, filename)

    def add_audio_url(self):
        url = self.audio_url.get().strip()
        if not url:
            return
        name = urllib.parse.unquote(Path(urllib.parse.urlparse(url).path).name) or "Web audio"
        self.add_track(name, url)
        self.audio_url.delete(0, "end")

    def add_track(self, name, source, radio_id=None):
        self.tracks.append({"name": name, "source": source, "radio_id": radio_id})
        self.playlist.insert("end", f"{len(self.tracks):02d}. {name}")
        self.status.set("TRACK ADDED")
        if self.current_index < 0:
            self.load_index(0)

    def load_index(self, value, autoplay=False):
        if not self.require_player() or not self.tracks:
            return
        self.current_index = max(0, min(value, len(self.tracks) - 1))
        track = self.tracks[self.current_index]
        media = self.instance.media_new(track["source"])
        self.player.set_media(media)
        self.current_radio_id = track.get("radio_id")
        self.track_text.set(track["name"])
        self.playlist.selection_clear(0, "end")
        self.playlist.selection_set(self.current_index)
        self.playlist.see(self.current_index)
        self.status.set(f"LOADED: {track['name'].upper()}")
        if autoplay:
            self.player.play()

    def play_selected(self, _event=None):
        selected = self.playlist.curselection()
        if selected:
            self.load_index(selected[0], autoplay=True)

    def play(self):
        if not self.require_player():
            return
        if self.current_index < 0 and self.tracks:
            self.load_index(0)
        if self.current_index >= 0:
            self.player.play()
            self.playing = True
            self.status.set("PLAYING")

    def pause(self):
        if self.player:
            self.player.pause()
            self.playing = False
            self.status.set("PAUSED")

    def stop(self):
        if self.player:
            self.player.stop()
            self.playing = False
            self.status.set("STOPPED")

    def previous(self):
        if self.tracks:
            self.load_index((self.current_index - 1) % len(self.tracks), autoplay=True)

    def next_track(self):
        if not self.tracks:
            return
        target = random.randrange(len(self.tracks)) if self.shuffle.get() and len(self.tracks) > 1 else (self.current_index + 1) % len(self.tracks)
        self.load_index(target, autoplay=True)

    def remove_selected(self):
        selected = self.playlist.curselection()
        if not selected:
            return
        i = selected[0]
        if i == self.current_index:
            self.stop()
        del self.tracks[i]
        self.refresh_playlist()
        self.current_index = min(self.current_index, len(self.tracks) - 1)
        if self.current_index >= 0:
            self.load_index(self.current_index)

    def clear_playlist(self):
        self.stop()
        self.tracks.clear()
        self.current_index = -1
        self.playlist.delete(0, "end")
        self.track_text.set("NO TRACK LOADED")

    def refresh_playlist(self):
        self.playlist.delete(0, "end")
        for i, track in enumerate(self.tracks, 1):
            self.playlist.insert("end", f"{i:02d}. {track['name']}")

    def change_volume(self, _value=None):
        if self.player:
            self.player.audio_set_volume(int(self.volume.get()))

    def change_balance(self, _value=None):
        # VLC's standard Python binding has no portable balance control.
        self.status.set(f"BALANCE DISPLAY: {self.balance.get()}")

    def seek_release(self, _event=None):
        self.dragging_seek = False
        if self.player:
            length = self.player.get_length()
            if length > 0:
                self.player.set_time(int((self.seek.get() / 1000) * length))

    def update_playback_ui(self):
        if self.player:
            now = max(0, self.player.get_time())
            length = max(0, self.player.get_length())
            if not self.dragging_seek and length > 0:
                self.seek.set((now / length) * 1000)
            self.time_text.set(f"{format_time(now / 1000)} / {format_time(length / 1000)}")
            self.player_canvas.itemconfigure(self.canvas_time, text=format_time(now / 1000))
            self.player_canvas.itemconfigure(self.canvas_track, text=self.track_text.get().upper())
            self.player_canvas.itemconfigure(self.canvas_status, text=f"{self.status.get()}  VOL {self.volume.get()}%  BAL {self.balance.get()}")
            state = self.player.get_state()
            if state == vlc.State.Ended:
                if self.repeat.get():
                    self.player.stop(); self.player.play()
                else:
                    self.next_track()
        self.after(250, self.update_playback_ui)

    def choose_skin(self):
        filename = filedialog.askopenfilename(title="Load Winamp skin", filetypes=SKIN_TYPES)
        if not filename:
            return
        try:
            suffix = Path(filename).suffix.lower()
            if suffix in (".wsz", ".zip"):
                with zipfile.ZipFile(filename) as archive:
                    lower = {name.lower().split("/")[-1]: name for name in archive.namelist()}
                    self.skin_images = {}
                    for skin_file in ("main.bmp", "pledit.bmp", "eqmain.bmp", "cbuttons.bmp", "titlebar.bmp", "posbar.bmp", "volume.bmp", "balance.bmp", "shufrep.bmp", "numbers.bmp"):
                        if skin_file in lower:
                            self.skin_images[skin_file] = archive.read(lower[skin_file])
                    if "main.bmp" not in self.skin_images:
                        raise ValueError("MAIN.BMP was not found in this skin.")
                self.apply_skin_bytes(self.skin_images["main.bmp"], self.skin_images.get("pledit.bmp"))
            else:
                self.apply_skin_bytes(Path(filename).read_bytes(), None)
            self.skin_name.set(Path(filename).name)
            self.status.set("SKIN APPLIED")
        except Exception as error:
            messagebox.showerror(APP_NAME, f"Could not load skin:\n{error}")
            self.status.set("SKIN ERROR")

    def apply_skin_bytes(self, main_data, playlist_data=None):
        if not Image or not ImageTk:
            raise RuntimeError("Install Pillow to display skin images.")
        image = Image.open(io.BytesIO(main_data)).convert("RGB").resize((550, 232), Image.Resampling.NEAREST)
        self.skin_photo = ImageTk.PhotoImage(image)
        self.player_canvas.create_image(0, 0, anchor="nw", image=self.skin_photo)
        self.player_canvas.tag_raise(self.canvas_track)
        self.player_canvas.tag_raise(self.canvas_time)
        self.player_canvas.tag_raise(self.canvas_status)
        if playlist_data:
            playlist_image = Image.open(io.BytesIO(playlist_data)).convert("RGB").resize((550, 232), Image.Resampling.NEAREST)
            self.playlist_skin_photo = ImageTk.PhotoImage(playlist_image)

    def reset_skin(self):
        self.skin_images.clear()
        self.skin_photo = None
        self.playlist_skin_photo = None
        self.player_canvas.delete("all")
        self.player_canvas.create_rectangle(0, 0, 550, 232, fill="#141a15", outline="")
        self.player_canvas.create_text(12, 12, anchor="nw", fill="#d8ffc1", font=("Consolas", 10, "bold"), text=APP_NAME.upper())
        self.canvas_track = self.player_canvas.create_text(220, 55, anchor="nw", width=310, fill="#a9ff79", font=("Consolas", 10), text=self.track_text.get())
        self.canvas_time = self.player_canvas.create_text(28, 52, anchor="nw", fill="#a9ff79", font=("Consolas", 26, "bold"), text="0:00")
        self.canvas_status = self.player_canvas.create_text(220, 85, anchor="nw", width=310, fill="#84a57a", font=("Consolas", 8), text="READY")
        self.skin_name.set("BUILT-IN RETRO")

    def load_stations(self):
        try:
            return json.loads(STATIONS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return []

    def save_stations(self):
        STATIONS_FILE.write_text(json.dumps(self.stations, indent=2), encoding="utf-8")
        self.refresh_station_list()

    def refresh_station_list(self):
        self.station_list.delete(0, "end")
        for station in self.stations:
            extra = ""
            if station.get("country") or station.get("genre"):
                extra = f"  [{station.get('country', '')} {station.get('genre', '')}]"
            self.station_list.insert("end", station["name"] + extra)

    def add_station(self):
        name, url = self.station_name.get().strip(), self.station_url.get().strip()
        if not name or not url or name == "Station name" or url == "Direct stream URL":
            messagebox.showwarning(APP_NAME, "Enter a station name and a direct stream URL.")
            return
        self.stations.append({"id": str(len(self.stations) + 1), "name": name, "url": url})
        self.save_stations()
        self.station_name.delete(0, "end"); self.station_url.delete(0, "end")

    def play_home_station(self):
        selected = self.station_list.curselection()
        if selected:
            self.tune_station(self.stations[selected[0]])

    def delete_station(self):
        selected = self.station_list.curselection()
        if selected:
            del self.stations[selected[0]]
            self.save_stations()

    def tune_station(self, station):
        existing = next((i for i, t in enumerate(self.tracks) if t.get("radio_id") == station.get("id")), -1)
        if existing < 0:
            self.add_track("RADIO: " + station["name"], station["url"], station.get("id"))
            existing = len(self.tracks) - 1
        self.load_index(existing, autoplay=True)

    def search_stations(self):
        self.status.set("SEARCHING RADIO DIRECTORY...")
        threading.Thread(target=self._search_worker, daemon=True).start()

    def _search_worker(self):
        params = {"limit": "50", "hidebroken": "true", "order": "votes", "reverse": "true"}
        name = self.search_name.get().strip()
        genre = self.genre.get()
        country = self.country.get()
        if name:
            params["name"] = name
        if genre and genre != "All genres":
            params["tag"] = genre
        if country and country != "All countries":
            params["countrycode"] = country
        try:
            request = urllib.request.Request(RADIO_API + "?" + urllib.parse.urlencode(params), headers={"User-Agent": APP_NAME})
            with urllib.request.urlopen(request, timeout=15) as response:
                data = json.loads(response.read().decode("utf-8"))
            results = [item for item in data if item.get("url_resolved")]
            self.after(0, lambda: self.show_directory_results(results))
        except Exception as error:
            self.after(0, lambda: self.status.set(f"DIRECTORY ERROR: {error}"))

    def show_directory_results(self, results):
        self.directory_results = results
        self.results.delete(*self.results.get_children())
        for i, station in enumerate(results):
            audio = f"{station.get('codec', '')} {station.get('bitrate', '')}".strip()
            self.results.insert("", "end", iid=str(i), text=station.get("name") or "Unnamed", values=(station.get("country", ""), station.get("tags", ""), audio))
        self.status.set(f"{len(results)} DIRECTORY STATIONS FOUND")

    def selected_directory_station(self):
        selected = self.results.selection()
        return self.directory_results[int(selected[0])] if selected else None

    def play_directory_station(self):
        station = self.selected_directory_station()
        if station:
            self.tune_station({"id": station.get("stationuuid"), "name": station.get("name", "Radio"), "url": station.get("url_resolved")})

    def save_directory_station(self):
        station = self.selected_directory_station()
        if not station:
            return
        station_id = station.get("stationuuid")
        if any(item.get("id") == station_id for item in self.stations):
            self.status.set("STATION ALREADY SAVED")
            return
        self.stations.append({"id": station_id, "name": station.get("name", "Radio"), "url": station.get("url_resolved"), "country": station.get("country", ""), "genre": station.get("tags", "")})
        self.save_stations()
        self.status.set("STATION SAVED TO HOME RADIO")

    def close(self):
        if self.player:
            self.player.stop()
        self.destroy()


if __name__ == "__main__":
    RetroPlayer().mainloop()
