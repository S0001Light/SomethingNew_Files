Writers Jumbler HTML5 New/Erase Repeat Error Fixed

Fixes the misleading "autoA stopped 0/10" message.

Changes:
- JavaScript results use JSON.stringify for reliable PySide conversion.
- Python accepts either a JSON string or dictionary result.
- The actual page error is preserved instead of being overwritten by the generic stopped message.
- Each cycle searches all live [id] elements, clicks every exact autoA or autoB match, counts one successful repeat, then waits the selected delay.
- Repeat count remains selectable and defaults to 10.
- GIF recording remains independent.
