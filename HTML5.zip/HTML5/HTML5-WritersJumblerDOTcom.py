import json
import sys
import time
from pathlib import Path

from PIL import Image
from PySide6.QtCore import QRect, Qt, QTimer, QUrl
from PySide6.QtGui import QGuiApplication, QPainter, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QProgressBar,
    QPushButton,
    QRubberBand,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)
from PySide6.QtWebEngineCore import QWebEngineScript
from PySide6.QtWebEngineWidgets import QWebEngineView

ROOT = Path(__file__).resolve().parent
HOME = QUrl("https://www.writersjumbler.com")
SESS = (
    Path.home()
    / ".writers_jumbler_viewer"
    / "sessions"
    / time.strftime("%Y%m%d-%H%M%S")
)
SESS.mkdir(parents=True, exist_ok=True)


class Shot(QWidget):
    def __init__(self):
        super().__init__(
            None,
            Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowStaysOnTopHint
            | Qt.WindowType.Tool,
        )
        screens = QGuiApplication.screens()
        geometry = screens[0].geometry()
        for screen in screens[1:]:
            geometry = geometry.united(screen.geometry())

        self.pic = QPixmap(geometry.size())
        self.pic.fill(Qt.GlobalColor.black)
        painter = QPainter(self.pic)
        for screen in screens:
            painter.drawPixmap(
                screen.geometry().topLeft() - geometry.topLeft(),
                screen.grabWindow(0),
            )
        painter.end()

        self.setGeometry(geometry)
        self.setWindowOpacity(0.3)
        self.rubber = QRubberBand(QRubberBand.Shape.Rectangle, self)
        self.origin = None

    def mousePressEvent(self, event):
        self.origin = event.position().toPoint()
        self.rubber.setGeometry(QRect(self.origin, self.origin))
        self.rubber.show()

    def mouseMoveEvent(self, event):
        if self.origin is not None:
            self.rubber.setGeometry(
                QRect(self.origin, event.position().toPoint()).normalized()
            )

    def mouseReleaseEvent(self, event):
        if self.origin is None:
            return
        rectangle = QRect(
            self.origin, event.position().toPoint()
        ).normalized()
        self.hide()
        path, _ = QFileDialog.getSaveFileName(
            self, "Save", "screenshot.png", "PNG (*.png)"
        )
        if path and rectangle.width() > 2 and rectangle.height() > 2:
            self.pic.copy(rectangle).save(path)
        self.close()


class Win(QMainWindow):
    def __init__(self):
        super().__init__()
        self.resize(1400, 900)
        self.setWindowTitle(
            "Writers Jumbler HTML5 New/Erase Repeat Error Fixed"
        )

        self.frames = []
        self.recording = False
        self.calls = 0
        self.done = 0
        self.func = ""
        self.delay = 100
        self.function_running = False

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        address = QHBoxLayout()
        layout.addLayout(address)
        address.addWidget(QLabel("Address:"))
        self.addr = QLineEdit()
        self.addr.returnPressed.connect(self.go)
        address.addWidget(self.addr, 1)

        controls = [
            ("Go", self.go),
            ("Home", self.home),
            ("Back", self.back),
            ("Forward", self.forward),
            ("Refresh", self.refresh),
            ("Zoom Out", self.zoom),
            ("Reset Zoom", self.reset_zoom),
            ("Screenshot", self.shot),
        ]
        for text, callback in controls:
            button = QPushButton(text)
            button.clicked.connect(callback)
            address.addWidget(button)

        recording = QHBoxLayout()
        layout.addLayout(recording)
        recording.addWidget(QLabel("Frames"))
        self.fc = QSpinBox()
        self.fc.setRange(1, 100000)
        self.fc.setValue(100)
        recording.addWidget(self.fc)

        recording.addWidget(QLabel("Interval ms"))
        self.fi = QSpinBox()
        self.fi.setRange(10, 60000)
        self.fi.setValue(100)
        recording.addWidget(self.fi)

        self.rb = QPushButton("Start Recording")
        self.rb.clicked.connect(self.startrec)
        recording.addWidget(self.rb)

        self.sb = QPushButton("Stop Recording")
        self.sb.clicked.connect(self.stoprec)
        self.sb.setEnabled(False)
        recording.addWidget(self.sb)

        save_button = QPushButton("Save GIF")
        save_button.clicked.connect(self.savegif)
        recording.addWidget(save_button)

        self.prog = QProgressBar()
        self.prog.hide()
        recording.addWidget(self.prog)

        repeat = QHBoxLayout()
        layout.addLayout(repeat)
        repeat.addWidget(QLabel("Function button repeats:"))

        self.auto_count = QSpinBox()
        self.auto_count.setRange(1, 100000)
        self.auto_count.setValue(10)
        repeat.addWidget(self.auto_count)

        repeat.addWidget(QLabel("Delay ms:"))
        self.auto_delay = QSpinBox()
        self.auto_delay.setRange(1, 600000)
        self.auto_delay.setValue(100)
        repeat.addWidget(self.auto_delay)

        self.stop_auto_button = QPushButton("Stop Function")
        self.stop_auto_button.clicked.connect(lambda: self.stop_auto_button_sequence(False))
        self.stop_auto_button.setEnabled(False)
        repeat.addWidget(self.stop_auto_button)

        self.press_counter = QLabel("Pressed: 0 / 0")
        repeat.addWidget(self.press_counter)
        repeat.addStretch(1)

        art = QHBoxLayout()
        layout.addLayout(art)
        art.addWidget(QLabel("Art controls:"))

        self.new_button = QPushButton("New")
        self.new_button.setMinimumHeight(38)
        self.new_button.clicked.connect(lambda: self.start_page_function("autoA"))
        art.addWidget(self.new_button)

        self.erase_button = QPushButton("Erase")
        self.erase_button.setMinimumHeight(38)
        self.erase_button.clicked.connect(lambda: self.start_page_function("autoB"))
        art.addWidget(self.erase_button)
        art.addStretch(1)

        self.status = QLabel("Ready")
        layout.addWidget(self.status)

        self.web = QWebEngineView()
        layout.addWidget(self.web, 1)
        self.web.urlChanged.connect(
            lambda url: self.addr.setText(url.toString())
        )
        self.web.titleChanged.connect(self.update_title)

        self.record_timer = QTimer(self)
        self.record_timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.record_timer.timeout.connect(self.cap)

        self.function_timer = QTimer(self)
        self.function_timer.setSingleShot(True)
        self.function_timer.setTimerType(Qt.TimerType.PreciseTimer)
        self.function_timer.timeout.connect(self.callfunc)

        self.web.setUrl(HOME)

    def update_title(self, title):
        base = "Writers Jumbler HTML5 New/Erase Repeat Error Fixed"
        self.setWindowTitle(f"{title} - {base}" if title else base)

    def go(self):
        text = self.addr.text().strip()
        if text:
            self.web.setUrl(QUrl.fromUserInput(text))

    def home(self):
        self.web.setUrl(HOME)

    def back(self):
        self.web.back()

    def forward(self):
        self.web.forward()

    def refresh(self):
        self.web.reload()

    def zoom(self):
        self.web.setZoomFactor(max(0.25, self.web.zoomFactor() - 0.1))

    def reset_zoom(self):
        self.web.setZoomFactor(1.0)

    def shot(self):
        self.shot_overlay = Shot()
        self.shot_overlay.show()

    def startrec(self):
        self.frames = []
        self.recording = True
        self.rb.setEnabled(False)
        self.sb.setEnabled(True)
        self.cap()
        if self.recording:
            self.record_timer.start(self.fi.value())

    def stoprec(self):
        self.recording = False
        self.record_timer.stop()
        self.rb.setEnabled(True)
        self.sb.setEnabled(False)
        self.status.setText(f"Recorded {len(self.frames)} frames")

    def cap(self):
        if not self.recording:
            return
        pixmap = self.web.grab()
        path = SESS / f"{len(self.frames) + 1:06d}.png"
        if pixmap.save(str(path), "PNG"):
            self.frames.append(str(path))
        self.status.setText(
            f"Recording {len(self.frames)}/{self.fc.value()}"
        )
        if len(self.frames) >= self.fc.value():
            self.stoprec()

    def savegif(self):
        if not self.frames:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save GIF", "recording.gif", "GIF (*.gif)"
        )
        if not path:
            return

        self.prog.show()
        images = []
        for index, filename in enumerate(self.frames, 1):
            with Image.open(filename) as image:
                images.append(
                    image.convert(
                        "P", palette=Image.Palette.ADAPTIVE
                    ).copy()
                )
            self.prog.setValue(int(index / len(self.frames) * 90))
            QApplication.processEvents()

        images[0].save(
            path,
            save_all=True,
            append_images=images[1:],
            duration=self.fi.value(),
            loop=0,
            optimize=True,
        )
        self.prog.setValue(100)
        self.status.setText("GIF saved")
        QTimer.singleShot(1200, self.prog.hide)

    def start_page_function(self, element_id):
        if self.function_running:
            self.stop_auto_button_sequence(False)

        self.func = element_id
        self.calls = self.auto_count.value()
        self.done = 0
        self.delay = self.auto_delay.value()
        self.function_running = True

        self.press_counter.setText(f"Pressed: 0 / {self.calls}")
        self.stop_auto_button.setEnabled(True)
        self.new_button.setEnabled(False)
        self.erase_button.setEnabled(False)
        self.status.setText(f"{element_id}: starting")

        # Nonblocking equivalent of:
        # for a in range(0, b): press_button(); wait(delay)
        self.callfunc()

    def callfunc(self):
        if not self.function_running:
            return
        if self.done >= self.calls:
            self.finish_function()
            return

        script = r"""
((wantedId) => {
    try {
        const elements = Array.from(document.querySelectorAll('[id]'))
            .filter(element => element.id === wantedId);

        if (elements.length === 0) {
            return JSON.stringify({
                ok: false,
                error: 'id="' + wantedId + '" was not found on this page'
            });
        }

        let executed = 0;
        let skipped = 0;

        for (const element of elements) {
            try {
                if (typeof element.click === 'function') {
                    element.focus();
                    element.click();
                    executed++;
                } else {
                    skipped++;
                }
            } catch (elementError) {
                skipped++;
            }
        }

        return JSON.stringify({
            ok: executed > 0,
            id: wantedId,
            matched: elements.length,
            executed: executed,
            skipped: skipped,
            error: executed > 0
                ? ''
                : 'Matching elements were found but none could be clicked'
        });
    } catch (error) {
        return JSON.stringify({
            ok: false,
            error: String(error && error.message ? error.message : error)
        });
    }
})(%s)
""" % json.dumps(self.func)

        self.web.page().runJavaScript(
            script,
            QWebEngineScript.ScriptWorldId.MainWorld,
            self.called,
        )

    def called(self, result):
        if not self.function_running:
            return

        try:
            data = json.loads(result) if isinstance(result, str) else result
            if not isinstance(data, dict):
                raise ValueError(f"Unexpected JavaScript result: {result!r}")
        except Exception as error:
            self.stop_auto_button_sequence(
                False,
                status_override=f"JavaScript result error: {error}",
            )
            return

        if not data.get("ok"):
            self.stop_auto_button_sequence(
                False,
                status_override=str(data.get("error", "Page command failed")),
            )
            return

        self.done += 1
        self.press_counter.setText(f"Pressed: {self.done} / {self.calls}")
        self.status.setText(
            f"{data.get('id', self.func)}: "
            f"{data.get('executed', 0)} clicked, "
            f"repeat {self.done}/{self.calls}"
        )

        if self.done < self.calls:
            self.function_timer.start(self.delay)
        else:
            self.finish_function()

    def finish_function(self):
        self.stop_auto_button_sequence(True)

    def stop_auto_button_sequence(
        self,
        completed=False,
        status_override=None,
    ):
        self.function_timer.stop()
        was_running = self.function_running
        self.function_running = False
        self.stop_auto_button.setEnabled(False)
        self.new_button.setEnabled(True)
        self.erase_button.setEnabled(True)

        if status_override:
            self.status.setText(status_override)
            return

        if completed:
            self.status.setText(
                f"{self.func} complete: {self.done}/{self.calls} confirmed executions"
            )
        elif was_running:
            self.status.setText(
                f"{self.func} stopped: {self.done}/{self.calls} confirmed executions"
            )

    def closeEvent(self, event):
        self.record_timer.stop()
        self.function_timer.stop()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Win()
    window.show()
    sys.exit(app.exec())
