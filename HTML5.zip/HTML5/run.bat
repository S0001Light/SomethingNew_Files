@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt
if errorlevel 1 pause & exit /b 1
py "%~dp0writers_jumbler_html5_new_erase_repeat_error_fixed.py"
if errorlevel 1 pause
