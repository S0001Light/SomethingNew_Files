import sys
import json
import html
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import urlopen, Request
from urllib.error import HTTPError, URLError

from PySide6.QtCore import Qt, QUrl, QThread, Signal
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLineEdit, QPushButton, QListWidget, QListWidgetItem, QLabel,
    QSlider, QMessageBox, QInputDialog, QSplitter
)
from PySide6.QtWebEngineWidgets import QWebEngineView
from PySide6.QtWebEngineCore import (
    QWebEngineSettings,
    QWebEngineUrlRequestInterceptor,
)

APP_DIR = Path.home() / ".wj_album_radio"
APP_DIR.mkdir(exist_ok=True)
SETTINGS = APP_DIR / "settings.json"
FAV = APP_DIR / "favorites.json"
HIST = APP_DIR / "history.json"
APP_ORIGIN = "https://writersjumbler.com"


def load_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2), encoding="utf-8")


class RefererInterceptor(QWebEngineUrlRequestInterceptor):
    """Identify this desktop client to the YouTube embedded player."""

    def interceptRequest(self, info):
        host = info.requestUrl().host().lower()
        if host.endswith("youtube.com") or host.endswith("youtube-nocookie.com"):
            info.setHttpHeader(b"Referer", (APP_ORIGIN + "/").encode("ascii"))


class SearchThread(QThread):
    done = Signal(list)
    error = Signal(str)

    def __init__(self, key, query):
        super().__init__()
        self.key = key
        self.query = query

    def run(self):
        try:
            params = urlencode({
                "part": "snippet",
                "type": "video",
                "maxResults": 25,
                "q": self.query + " full album music",
                "videoEmbeddable": "true",
                "key": self.key,
            })
            request = Request(
                "https://www.googleapis.com/youtube/v3/search?" + params,
                headers={"User-Agent": "WJAlbumRadio/1.1"},
            )
            with urlopen(request, timeout=20) as response:
                data = json.load(response)

            results = []
            for item in data.get("items", []):
                video_id = item.get("id", {}).get("videoId")
                snippet = item.get("snippet", {})
                title = html.unescape(snippet.get("title", ""))
                lowered = title.lower()
                if video_id and ("album" in lowered or "full" in lowered):
                    results.append({
                        "id": video_id,
                        "title": title,
                        "channel": html.unescape(snippet.get("channelTitle", "")),
                    })
            self.done.emit(results)
        except HTTPError as exc:
            try:
                details = exc.read().decode("utf-8", errors="replace")
            except Exception:
                details = ""
            self.error.emit(
                "YouTube API error: %s %s\n%s" %
                (exc.code, exc.reason, details[:500])
            )
        except URLError as exc:
            self.error.emit("Network error: " + str(exc.reason))
        except Exception as exc:
            self.error.emit(str(exc))


class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("WritersJumbler Album Radio")
        self.resize(1100, 760)

        self.settings = load_json(SETTINGS, {})
        self.favs = load_json(FAV, [])
        self.hist = load_json(HIST, [])
        self.results = []
        self.current = -1
        self.player_state = "stopped"
        self.worker = None

        root = QWidget()
        self.setCentralWidget(root)
        layout = QVBoxLayout(root)

        top = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Artist or album - full albums only")
        self.go = QPushButton("SEARCH")
        self.keybtn = QPushButton("API KEY")
        top.addWidget(self.search, 1)
        top.addWidget(self.go)
        top.addWidget(self.keybtn)
        layout.addLayout(top)

        split = QSplitter()

        left = QWidget()
        left_layout = QVBoxLayout(left)
        left_layout.addWidget(QLabel("FULL ALBUM RESULTS"))
        self.list = QListWidget()
        left_layout.addWidget(self.list)
        split.addWidget(left)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        self.now = QLabel("RADIO IDLE")
        self.now.setWordWrap(True)
        right_layout.addWidget(self.now)

        self.web = QWebEngineView()
        self.web.setMinimumSize(360, 203)
        self.web.settings().setAttribute(
            QWebEngineSettings.WebAttribute.PlaybackRequiresUserGesture,
            False,
        )
        self.interceptor = RefererInterceptor(self.web)
        self.web.page().profile().setUrlRequestInterceptor(self.interceptor)
        right_layout.addWidget(self.web, 1)
        split.addWidget(right)
        split.setSizes([430, 650])
        layout.addWidget(split, 1)

        controls = QHBoxLayout()
        self.prev = QPushButton("PREVIOUS")
        self.play = QPushButton("PLAY / PAUSE")
        self.next = QPushButton("NEXT")
        self.fav = QPushButton("FAVORITE")
        for button in (self.prev, self.play, self.next, self.fav):
            controls.addWidget(button)
        layout.addLayout(controls)

        volume_row = QHBoxLayout()
        volume_row.addWidget(QLabel("VOLUME"))
        self.volume = QSlider(Qt.Horizontal)
        self.volume.setRange(0, 100)
        self.volume.setValue(75)
        volume_row.addWidget(self.volume)
        layout.addLayout(volume_row)

        self.status = QLabel(
            "Enter a YouTube Data API key, then search for an artist or album."
        )
        self.status.setWordWrap(True)
        layout.addWidget(self.status)

        self.setStyleSheet(
            "QMainWindow,QWidget{background:#111;color:#eee;font:14px Consolas;}"
            "QLineEdit,QListWidget{background:#1d1d1d;color:#8cff66;"
            "border:1px solid #555;padding:7px;}"
            "QPushButton{background:#303030;color:white;border:1px solid #777;"
            "padding:8px;}"
            "QPushButton:hover{background:#444;} QLabel{padding:3px;}"
        )

        self.go.clicked.connect(self.do_search)
        self.search.returnPressed.connect(self.do_search)
        self.keybtn.clicked.connect(self.set_key)
        self.list.itemDoubleClicked.connect(
            lambda _: self.play_index(self.list.currentRow())
        )
        self.prev.clicked.connect(lambda: self.play_index(self.current - 1))
        self.next.clicked.connect(lambda: self.play_index(self.current + 1))
        self.play.clicked.connect(self.toggle)
        self.volume.valueChanged.connect(self.set_volume)
        self.fav.clicked.connect(self.favorite)

        self.show_idle_page()

    def show_idle_page(self):
        page = """<!doctype html>
<html><head><meta name="referrer" content="strict-origin-when-cross-origin">
<style>html,body{height:100%;margin:0;background:#000;color:#aaa;font-family:sans-serif}
body{display:flex;align-items:center;justify-content:center}</style></head>
<body><h2>WJ Album Radio</h2></body></html>"""
        self.web.setHtml(page, QUrl(APP_ORIGIN + "/"))

    def set_key(self):
        key, ok = QInputDialog.getText(
            self,
            "YouTube API key",
            "YouTube Data API v3 key:",
            QLineEdit.Password,
            self.settings.get("api_key", ""),
        )
        if ok and key.strip():
            self.settings["api_key"] = key.strip()
            save_json(SETTINGS, self.settings)
            self.status.setText("API key saved locally.")

    def do_search(self):
        query = self.search.text().strip()
        if not query:
            self.status.setText("Enter an artist or album first.")
            return

        key = self.settings.get("api_key", "")
        if not key:
            self.set_key()
            key = self.settings.get("api_key", "")
        if not key:
            return

        self.go.setEnabled(False)
        self.status.setText("Searching YouTube for full albums...")
        self.worker = SearchThread(key, query)
        self.worker.done.connect(self.got)
        self.worker.error.connect(self.failed)
        self.worker.start()

    def got(self, items):
        self.go.setEnabled(True)
        self.results = items
        self.list.clear()
        for item in items:
            self.list.addItem(
                QListWidgetItem(item["title"] + "\n" + item["channel"])
            )
        if items:
            self.status.setText(
                "%d album-oriented results. Double-click one to tune in."
                % len(items)
            )
        else:
            self.status.setText(
                "No album-oriented results were returned. Try another artist or album."
            )

    def failed(self, message):
        self.go.setEnabled(True)
        self.status.setText(message)
        QMessageBox.warning(self, "Search failed", message)

    def player_html(self, video_id):
        return f"""<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="referrer" content="strict-origin-when-cross-origin">
<style>
html,body,#player{{width:100%;height:100%;margin:0;background:#000;overflow:hidden}}
</style>
<script src="https://www.youtube.com/iframe_api"></script>
<script>
var player = null;
var ready = false;
function onYouTubeIframeAPIReady() {{
  player = new YT.Player('player', {{
    videoId: '{video_id}',
    width: '100%',
    height: '100%',
    playerVars: {{
      autoplay: 1,
      playsinline: 1,
      origin: '{APP_ORIGIN}'
    }},
    events: {{
      onReady: function(e) {{ ready = true; e.target.setVolume(75); e.target.playVideo(); }},
      onStateChange: function(e) {{
        if (e.data === YT.PlayerState.ENDED) document.title = 'WJ_ENDED';
        else if (e.data === YT.PlayerState.PLAYING) document.title = 'WJ_PLAYING';
        else if (e.data === YT.PlayerState.PAUSED) document.title = 'WJ_PAUSED';
      }},
      onError: function(e) {{ document.title = 'WJ_ERROR_' + e.data; }}
    }}
  }});
}}
function togglePlayback() {{
  if (!ready || !player) return;
  if (player.getPlayerState() === YT.PlayerState.PLAYING) player.pauseVideo();
  else player.playVideo();
}}
function setPlayerVolume(value) {{
  if (ready && player) player.setVolume(Math.max(0, Math.min(100, value)));
}}
</script>
</head>
<body><div id="player"></div></body>
</html>"""

    def play_index(self, index):
        if not self.results:
            return
        index %= len(self.results)
        self.current = index
        item = self.results[index]
        self.list.setCurrentRow(index)
        self.now.setText(
            "NOW PLAYING\n" + item["title"] + "\n" + item["channel"]
        )
        self.player_state = "playing"
        self.web.setHtml(
            self.player_html(item["id"]),
            QUrl(APP_ORIGIN + "/album-radio/"),
        )
        self.hist.insert(0, item)
        self.hist = self.hist[:100]
        save_json(HIST, self.hist)

    def toggle(self):
        if self.current < 0:
            return
        self.web.page().runJavaScript("togglePlayback();")

    def set_volume(self, value):
        self.web.page().runJavaScript("setPlayerVolume(%d);" % value)

    def favorite(self):
        if 0 <= self.current < len(self.results):
            item = self.results[self.current]
            if not any(f.get("id") == item["id"] for f in self.favs):
                self.favs.append(item)
                save_json(FAV, self.favs)
                self.status.setText("Saved to favorites.")
            else:
                self.status.setText("This album is already in favorites.")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Window()
    window.show()
    sys.exit(app.exec())
