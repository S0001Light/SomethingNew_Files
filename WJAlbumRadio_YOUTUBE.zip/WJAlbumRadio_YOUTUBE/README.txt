WritersJumbler Album Radio
=========================

SHAREABLE BUILD
This package does NOT contain the developer's YouTube API key.
Each user should create and enter their own YouTube Data API v3 API key.

INSTALL THE APP
1. Install Python 3.10 or newer.
2. Extract this ZIP to a folder.
3. Open Command Prompt in that folder.
4. Run:

   py -m pip install -r requirements.txt

5. Start the program:

   py album_radio.py

HOW TO GET A YOUTUBE DATA API KEY
1. Sign in to your Google Account and open Google Cloud Console:
   https://console.cloud.google.com/

2. Create a new Google Cloud project, or select a project you want to use.

3. Open the API Library for that project.

4. Search for:

   YouTube Data API v3

5. Open YouTube Data API v3 and enable it for the project.

6. Open the Credentials page in Google Cloud Console.

7. Choose Create credentials, then API key.

8. Copy the new API key.

ADD THE KEY TO WJ ALBUM RADIO
1. Start album_radio.py.
2. Click API KEY.
3. Paste your YouTube Data API v3 key.
4. Click OK.
5. Search for an artist or album.

The app saves the entered key locally in the current user's home folder:

   .wj_album_radio/settings.json

That settings file is created when that user runs/configures the program. It is not included in this shareable ZIP.

IMPORTANT
Do not add your personal API key directly to album_radio.py before sharing the program.
Do not include your .wj_album_radio/settings.json file in a public download.

The app uses its API key for public YouTube search data. It does not need OAuth merely to perform those public-data searches.

OFFICIAL GOOGLE DOCUMENTATION
YouTube Data API overview:
https://developers.google.com/youtube/data/getting-started

YouTube Data API authentication:
https://developers.google.com/youtube/data/guides/authentication

Google Cloud Console:
https://console.cloud.google.com/
